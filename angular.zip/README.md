#v1.0

- Cadastro de projetos, itens de projeto, categoria de item, categoria de custo.
