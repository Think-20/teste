export const environment = {
  production: true,
  api: 'https://companybook.ddns.net:8000'
};
