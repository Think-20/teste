export class BriefingLevel {
    id: number
    description: string
}
