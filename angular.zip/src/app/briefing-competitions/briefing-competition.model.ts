export class BriefingCompetition {
    id: number
    description: string
}
