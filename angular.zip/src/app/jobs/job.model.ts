export class Job {
    id: number
    description: string
}
