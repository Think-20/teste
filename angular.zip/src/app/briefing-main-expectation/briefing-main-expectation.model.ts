export class BriefingMainExpectation {
    id: number
    description: string
}
