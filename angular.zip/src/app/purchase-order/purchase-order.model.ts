export class PurchaseOrder {
    projectId: number
    itemId: number
    estimatedValue: number
    realValue: number
    measureId: number
    quantity: number
    finalityId: number
}