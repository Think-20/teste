export class ItemType {
    id: number
    description: string
}