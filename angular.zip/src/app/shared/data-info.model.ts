import { Pagination } from "./pagination.model";

export class DataInfo {
  updatedInfo: string
  pagination?: Pagination
}
