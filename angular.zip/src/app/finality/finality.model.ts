export class Finality {
    id : number
    description : string
}