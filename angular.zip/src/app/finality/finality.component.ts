import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'cb-finality',
  templateUrl: './finality.component.html',
  styleUrls: ['./finality.component.css']
})
export class FinalityComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
