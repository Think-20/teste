export class BriefingPresentation {
    id: number
    description: string
}
