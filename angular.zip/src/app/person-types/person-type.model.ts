export class PersonType {
    id: number
    description: string
}