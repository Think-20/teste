export class StandGenre {
    id: number
    description: string
}
