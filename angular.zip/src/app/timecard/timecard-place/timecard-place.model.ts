export class TimecardPlace {
  id: number
  description: string
}
