import { environment } from '../environments/environment'

export const API = environment.api