export class Bank {
    id: number
    name: string
}