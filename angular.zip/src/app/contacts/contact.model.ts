export class Contact {
    id: number
    name: string
    department: string
    cellphone: number
    email: string
}