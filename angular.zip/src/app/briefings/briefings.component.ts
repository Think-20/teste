import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'cb-briefings',
  templateUrl: './briefings.component.html',
  styleUrls: ['./briefings.component.css']
})
export class BriefingsComponent implements OnInit {

  ngOnInit() {

  }

}

