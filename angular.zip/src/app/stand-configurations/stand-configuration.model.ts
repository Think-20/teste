export class StandConfiguration {
    id: number
    description: string
}
