export class BriefingHowCome {
    id: number
    description: string
}
