import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'cb-cost-categories',
  templateUrl: './cost-categories.component.html'
})
export class CostCategoriesComponent implements OnInit {

  ngOnInit() { }

}

