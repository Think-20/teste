export class CostCategory {
    id: number
    description: string
}