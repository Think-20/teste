export class ItemCategory {
    id: number
    description: string
    item_category?: ItemCategory
}