import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'cb-item-categories',
  templateUrl: './item-categories.component.html'
})
export class ItemCategoriesComponent implements OnInit {

  ngOnInit() { }

}

