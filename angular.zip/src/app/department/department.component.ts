import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'cb-department',
  templateUrl: './department.component.html',
  styleUrls: ['./department.component.css']
})
export class DepartmentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
