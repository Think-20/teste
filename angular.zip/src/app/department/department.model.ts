export class Department {
    id: number
    description: string
}