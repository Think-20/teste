export class Position {
    id: number
    name: string
    description?: string
}