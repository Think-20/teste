export class BriefingSpecialPresentation {
    id: number
    description: string
}
