import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'cb-providers',
  templateUrl: './providers.component.html',
  styleUrls: ['./providers.component.css']
})
export class ProvidersComponent implements OnInit {

  ngOnInit() {    

  }

}

