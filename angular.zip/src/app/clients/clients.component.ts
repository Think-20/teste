import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'cb-clients',
  templateUrl: './clients.component.html',
  styleUrls: ['./clients.component.css']
})
export class ClientsComponent implements OnInit {

  ngOnInit() {    

  }

}

