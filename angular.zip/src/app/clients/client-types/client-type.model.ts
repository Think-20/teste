export class ClientType {
    id: number
    description: string
}