export class ClientStatus {
    id: number
    description: string
}