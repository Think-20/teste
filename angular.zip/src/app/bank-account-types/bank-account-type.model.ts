export class BankAccountType {
    id: number
    description: string
}