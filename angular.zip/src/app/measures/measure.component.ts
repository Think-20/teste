import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'cb-measure',
  templateUrl: './measure.component.html',
  styleUrls: ['./measure.component.css']
})
export class MeasureComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
