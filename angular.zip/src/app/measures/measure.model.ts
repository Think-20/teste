export class Measure {
    id : number
    description : string
}