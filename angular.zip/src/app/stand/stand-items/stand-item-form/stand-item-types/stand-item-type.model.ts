export class StandItemType {
  id: number
  description: string
}
