export class JobType {
    id: number
    description: string
}
