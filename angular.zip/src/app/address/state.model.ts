export class State {
    id: number
    name: string
    code: string
}